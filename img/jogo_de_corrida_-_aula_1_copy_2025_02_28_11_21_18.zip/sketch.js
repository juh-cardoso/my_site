function setup() {
  
  createCanvas(900, 400);
}

let xJogador1 = 0;
let xJogador2 = 0;

function draw() {
  background(300);
   background("black");
  textSize(30);
  text("👾", xJogador1, 200);
  text("🧐", xJogador2, 300);
  rect(850, 3, 10, 1000);
  xJogador1 += random(9);
  xJogador2 += random(5);
 rect(15, 3, 10, 1000)
}
